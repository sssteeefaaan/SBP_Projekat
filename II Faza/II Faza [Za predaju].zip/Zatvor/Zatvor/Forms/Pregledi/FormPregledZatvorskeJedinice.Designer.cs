﻿
namespace Zatvor.Forms.Pregledi
{
    partial class FormPregledZatvorskeJedinice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxCelijskiPeriod = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonObrisiTP = new System.Windows.Forms.Button();
            this.buttonIzmeniCP = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajCP = new System.Windows.Forms.Button();
            this.listViewCelijskiPeriodi = new System.Windows.Forms.ListView();
            this.buttonObrisiCP = new System.Windows.Forms.Button();
            this.groupBoxFirme = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajFirmu = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonIzmeniFirmu = new System.Windows.Forms.Button();
            this.buttonObrisiFirmu = new System.Windows.Forms.Button();
            this.listViewFirme = new System.Windows.Forms.ListView();
            this.groupBoxTerminiPosete = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonIzmeniTP = new System.Windows.Forms.Button();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajTP = new System.Windows.Forms.Button();
            this.listViewTerminiPosete = new System.Windows.Forms.ListView();
            this.groupBoxTerminiSetnje = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajTS = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonIzmeniTS = new System.Windows.Forms.Button();
            this.buttonObrisiTS = new System.Windows.Forms.Button();
            this.listViewTerminiSetnje = new System.Windows.Forms.ListView();
            this.groupBoxRezim = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxOtvoren = new System.Windows.Forms.CheckBox();
            this.checkBoxStrogi = new System.Windows.Forms.CheckBox();
            this.checkBoxPoluotvoren = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBoxZatvorenici = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonIzmeniZatvorenika = new System.Windows.Forms.Button();
            this.buttonObrisiZatvorenika = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajZatvorenika = new System.Windows.Forms.Button();
            this.listViewZatvorenici = new System.Windows.Forms.ListView();
            this.groupBoxZaposleni = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.radioButtonSvi = new System.Windows.Forms.RadioButton();
            this.radioButtonAdministracija = new System.Windows.Forms.RadioButton();
            this.radioButtonPsiholozi = new System.Windows.Forms.RadioButton();
            this.radioButtonObezbedjenje = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonIzmeniZaposlenog = new System.Windows.Forms.Button();
            this.buttonObrisiZaposlenog = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDodajZaposlenog = new System.Windows.Forms.Button();
            this.listViewZaposleni = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxCelijskiPeriod.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.groupBoxFirme.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBoxTerminiPosete.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBoxTerminiSetnje.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBoxRezim.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.groupBoxZatvorenici.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBoxZaposleni.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxCelijskiPeriod
            // 
            this.groupBoxCelijskiPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxCelijskiPeriod.Controls.Add(this.tableLayoutPanel3);
            this.groupBoxCelijskiPeriod.Controls.Add(this.tableLayoutPanel4);
            this.groupBoxCelijskiPeriod.Controls.Add(this.listViewCelijskiPeriodi);
            this.groupBoxCelijskiPeriod.Location = new System.Drawing.Point(51, 1084);
            this.groupBoxCelijskiPeriod.Name = "groupBoxCelijskiPeriod";
            this.groupBoxCelijskiPeriod.Size = new System.Drawing.Size(714, 304);
            this.groupBoxCelijskiPeriod.TabIndex = 6;
            this.groupBoxCelijskiPeriod.TabStop = false;
            this.groupBoxCelijskiPeriod.Text = "Ćelijski period";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.buttonObrisiTP, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.buttonIzmeniCP, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(508, 25);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel3.TabIndex = 6;
            // 
            // buttonObrisiTP
            // 
            this.buttonObrisiTP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiTP.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiTP.Name = "buttonObrisiTP";
            this.buttonObrisiTP.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiTP.TabIndex = 2;
            this.buttonObrisiTP.Text = "Obriši";
            this.buttonObrisiTP.UseVisualStyleBackColor = true;
            this.buttonObrisiTP.Click += new System.EventHandler(this.buttonObrisiTP_Click);
            // 
            // buttonIzmeniCP
            // 
            this.buttonIzmeniCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniCP.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniCP.Name = "buttonIzmeniCP";
            this.buttonIzmeniCP.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniCP.TabIndex = 1;
            this.buttonIzmeniCP.Text = "Izmeni";
            this.buttonIzmeniCP.Click += new System.EventHandler(this.buttonIzmeniCP_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.buttonDodajCP, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 25);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(100, 43);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // buttonDodajCP
            // 
            this.buttonDodajCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajCP.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajCP.Name = "buttonDodajCP";
            this.buttonDodajCP.Size = new System.Drawing.Size(94, 37);
            this.buttonDodajCP.TabIndex = 0;
            this.buttonDodajCP.Text = "Dodaj";
            this.buttonDodajCP.UseVisualStyleBackColor = true;
            this.buttonDodajCP.Click += new System.EventHandler(this.buttonDodajCP_Click);
            // 
            // listViewCelijskiPeriodi
            // 
            this.listViewCelijskiPeriodi.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewCelijskiPeriodi.HideSelection = false;
            this.listViewCelijskiPeriodi.Location = new System.Drawing.Point(3, 74);
            this.listViewCelijskiPeriodi.Name = "listViewCelijskiPeriodi";
            this.listViewCelijskiPeriodi.Size = new System.Drawing.Size(708, 227);
            this.listViewCelijskiPeriodi.TabIndex = 1;
            this.listViewCelijskiPeriodi.UseCompatibleStateImageBehavior = false;
            this.listViewCelijskiPeriodi.SelectedIndexChanged += new System.EventHandler(this.listViewCelijskiPeriodi_SelectedIndexChanged);
            // 
            // buttonObrisiCP
            // 
            this.buttonObrisiCP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiCP.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiCP.Name = "buttonObrisiCP";
            this.buttonObrisiCP.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiCP.TabIndex = 2;
            this.buttonObrisiCP.Text = "Obriši";
            this.buttonObrisiCP.UseVisualStyleBackColor = true;
            this.buttonObrisiCP.Click += new System.EventHandler(this.buttonObrisiCP_Click);
            // 
            // groupBoxFirme
            // 
            this.groupBoxFirme.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxFirme.Controls.Add(this.tableLayoutPanel6);
            this.groupBoxFirme.Controls.Add(this.tableLayoutPanel5);
            this.groupBoxFirme.Controls.Add(this.listViewFirme);
            this.groupBoxFirme.Location = new System.Drawing.Point(51, 774);
            this.groupBoxFirme.Name = "groupBoxFirme";
            this.groupBoxFirme.Size = new System.Drawing.Size(714, 304);
            this.groupBoxFirme.TabIndex = 5;
            this.groupBoxFirme.TabStop = false;
            this.groupBoxFirme.Text = "Firme";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.buttonDodajFirmu, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(6, 25);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(100, 43);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // buttonDodajFirmu
            // 
            this.buttonDodajFirmu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajFirmu.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajFirmu.Name = "buttonDodajFirmu";
            this.buttonDodajFirmu.Size = new System.Drawing.Size(94, 37);
            this.buttonDodajFirmu.TabIndex = 0;
            this.buttonDodajFirmu.Text = "Dodaj";
            this.buttonDodajFirmu.UseVisualStyleBackColor = true;
            this.buttonDodajFirmu.Click += new System.EventHandler(this.buttonDodajFirmu_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.buttonIzmeniFirmu, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.buttonObrisiFirmu, 1, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(511, 22);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // buttonIzmeniFirmu
            // 
            this.buttonIzmeniFirmu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniFirmu.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniFirmu.Name = "buttonIzmeniFirmu";
            this.buttonIzmeniFirmu.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniFirmu.TabIndex = 1;
            this.buttonIzmeniFirmu.Text = "Izmeni";
            this.buttonIzmeniFirmu.UseVisualStyleBackColor = true;
            this.buttonIzmeniFirmu.Click += new System.EventHandler(this.buttonIzmeniFirmu_Click);
            // 
            // buttonObrisiFirmu
            // 
            this.buttonObrisiFirmu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiFirmu.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiFirmu.Name = "buttonObrisiFirmu";
            this.buttonObrisiFirmu.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiFirmu.TabIndex = 2;
            this.buttonObrisiFirmu.Text = "Obriši";
            this.buttonObrisiFirmu.UseVisualStyleBackColor = true;
            this.buttonObrisiFirmu.Click += new System.EventHandler(this.buttonObrisiFirmu_Click);
            // 
            // listViewFirme
            // 
            this.listViewFirme.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewFirme.HideSelection = false;
            this.listViewFirme.Location = new System.Drawing.Point(3, 74);
            this.listViewFirme.Name = "listViewFirme";
            this.listViewFirme.Size = new System.Drawing.Size(708, 227);
            this.listViewFirme.TabIndex = 3;
            this.listViewFirme.UseCompatibleStateImageBehavior = false;
            this.listViewFirme.SelectedIndexChanged += new System.EventHandler(this.listViewFirme_SelectedIndexChanged);
            this.listViewFirme.DoubleClick += new System.EventHandler(this.listViewFirme_DoubleClick);
            // 
            // groupBoxTerminiPosete
            // 
            this.groupBoxTerminiPosete.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxTerminiPosete.Controls.Add(this.tableLayoutPanel8);
            this.groupBoxTerminiPosete.Controls.Add(this.tableLayoutPanel7);
            this.groupBoxTerminiPosete.Controls.Add(this.listViewTerminiPosete);
            this.groupBoxTerminiPosete.Location = new System.Drawing.Point(51, 1704);
            this.groupBoxTerminiPosete.Name = "groupBoxTerminiPosete";
            this.groupBoxTerminiPosete.Size = new System.Drawing.Size(714, 304);
            this.groupBoxTerminiPosete.TabIndex = 8;
            this.groupBoxTerminiPosete.TabStop = false;
            this.groupBoxTerminiPosete.Text = "Termini dozvole posete";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.buttonIzmeniTP, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.buttonObrisiCP, 1, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(511, 25);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel8.TabIndex = 7;
            // 
            // buttonIzmeniTP
            // 
            this.buttonIzmeniTP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniTP.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniTP.Name = "buttonIzmeniTP";
            this.buttonIzmeniTP.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniTP.TabIndex = 5;
            this.buttonIzmeniTP.Text = "Izmeni";
            this.buttonIzmeniTP.UseVisualStyleBackColor = true;
            this.buttonIzmeniTP.Click += new System.EventHandler(this.buttonIzmeniTP_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.buttonDodajTP, 0, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(6, 25);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(103, 43);
            this.tableLayoutPanel7.TabIndex = 6;
            // 
            // buttonDodajTP
            // 
            this.buttonDodajTP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajTP.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajTP.Name = "buttonDodajTP";
            this.buttonDodajTP.Size = new System.Drawing.Size(97, 37);
            this.buttonDodajTP.TabIndex = 0;
            this.buttonDodajTP.Text = "Dodaj";
            this.buttonDodajTP.UseVisualStyleBackColor = true;
            this.buttonDodajTP.Click += new System.EventHandler(this.buttonDodajTP_Click);
            // 
            // listViewTerminiPosete
            // 
            this.listViewTerminiPosete.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewTerminiPosete.HideSelection = false;
            this.listViewTerminiPosete.Location = new System.Drawing.Point(3, 74);
            this.listViewTerminiPosete.Name = "listViewTerminiPosete";
            this.listViewTerminiPosete.Size = new System.Drawing.Size(708, 227);
            this.listViewTerminiPosete.TabIndex = 3;
            this.listViewTerminiPosete.UseCompatibleStateImageBehavior = false;
            this.listViewTerminiPosete.SelectedIndexChanged += new System.EventHandler(this.listViewTerminiPosete_SelectedIndexChanged);
            // 
            // groupBoxTerminiSetnje
            // 
            this.groupBoxTerminiSetnje.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxTerminiSetnje.Controls.Add(this.tableLayoutPanel2);
            this.groupBoxTerminiSetnje.Controls.Add(this.tableLayoutPanel1);
            this.groupBoxTerminiSetnje.Controls.Add(this.listViewTerminiSetnje);
            this.groupBoxTerminiSetnje.Location = new System.Drawing.Point(51, 1394);
            this.groupBoxTerminiSetnje.Name = "groupBoxTerminiSetnje";
            this.groupBoxTerminiSetnje.Size = new System.Drawing.Size(714, 304);
            this.groupBoxTerminiSetnje.TabIndex = 7;
            this.groupBoxTerminiSetnje.TabStop = false;
            this.groupBoxTerminiSetnje.Text = "Termini dozvole šetnje";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.buttonDodajTS, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 25);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(97, 43);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // buttonDodajTS
            // 
            this.buttonDodajTS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajTS.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajTS.Name = "buttonDodajTS";
            this.buttonDodajTS.Size = new System.Drawing.Size(91, 37);
            this.buttonDodajTS.TabIndex = 0;
            this.buttonDodajTS.Text = "Dodaj";
            this.buttonDodajTS.UseVisualStyleBackColor = true;
            this.buttonDodajTS.Click += new System.EventHandler(this.buttonDodajTS_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.buttonIzmeniTS, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonObrisiTS, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(508, 22);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // buttonIzmeniTS
            // 
            this.buttonIzmeniTS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniTS.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniTS.Name = "buttonIzmeniTS";
            this.buttonIzmeniTS.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniTS.TabIndex = 2;
            this.buttonIzmeniTS.Text = "Izmeni";
            this.buttonIzmeniTS.UseVisualStyleBackColor = true;
            this.buttonIzmeniTS.Click += new System.EventHandler(this.buttonIzmeniTS_Click);
            // 
            // buttonObrisiTS
            // 
            this.buttonObrisiTS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiTS.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiTS.Name = "buttonObrisiTS";
            this.buttonObrisiTS.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiTS.TabIndex = 3;
            this.buttonObrisiTS.Text = "Obriši";
            this.buttonObrisiTS.UseVisualStyleBackColor = true;
            this.buttonObrisiTS.Click += new System.EventHandler(this.buttonObrisiTS_Click);
            // 
            // listViewTerminiSetnje
            // 
            this.listViewTerminiSetnje.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewTerminiSetnje.HideSelection = false;
            this.listViewTerminiSetnje.Location = new System.Drawing.Point(3, 74);
            this.listViewTerminiSetnje.Name = "listViewTerminiSetnje";
            this.listViewTerminiSetnje.Size = new System.Drawing.Size(708, 227);
            this.listViewTerminiSetnje.TabIndex = 1;
            this.listViewTerminiSetnje.UseCompatibleStateImageBehavior = false;
            this.listViewTerminiSetnje.SelectedIndexChanged += new System.EventHandler(this.listViewTerminiSetnje_SelectedIndexChanged);
            // 
            // groupBoxRezim
            // 
            this.groupBoxRezim.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxRezim.Controls.Add(this.tableLayoutPanel14);
            this.groupBoxRezim.Location = new System.Drawing.Point(48, 677);
            this.groupBoxRezim.Name = "groupBoxRezim";
            this.groupBoxRezim.Size = new System.Drawing.Size(717, 91);
            this.groupBoxRezim.TabIndex = 4;
            this.groupBoxRezim.TabStop = false;
            this.groupBoxRezim.Text = "Režim rada";
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Controls.Add(this.checkBoxOtvoren, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.checkBoxStrogi, 2, 0);
            this.tableLayoutPanel14.Controls.Add(this.checkBoxPoluotvoren, 1, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(142, 25);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(425, 50);
            this.tableLayoutPanel14.TabIndex = 3;
            // 
            // checkBoxOtvoren
            // 
            this.checkBoxOtvoren.AutoSize = true;
            this.checkBoxOtvoren.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxOtvoren.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxOtvoren.Location = new System.Drawing.Point(3, 3);
            this.checkBoxOtvoren.Name = "checkBoxOtvoren";
            this.checkBoxOtvoren.Size = new System.Drawing.Size(135, 44);
            this.checkBoxOtvoren.TabIndex = 0;
            this.checkBoxOtvoren.Text = "Otvoren režim";
            this.checkBoxOtvoren.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxOtvoren.UseVisualStyleBackColor = true;
            this.checkBoxOtvoren.CheckedChanged += new System.EventHandler(this.checkBoxOtvoren_CheckedChanged);
            // 
            // checkBoxStrogi
            // 
            this.checkBoxStrogi.AutoSize = true;
            this.checkBoxStrogi.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxStrogi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxStrogi.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxStrogi.Location = new System.Drawing.Point(285, 3);
            this.checkBoxStrogi.Name = "checkBoxStrogi";
            this.checkBoxStrogi.Size = new System.Drawing.Size(137, 44);
            this.checkBoxStrogi.TabIndex = 2;
            this.checkBoxStrogi.Text = "Strogi režim";
            this.checkBoxStrogi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxStrogi.UseVisualStyleBackColor = true;
            this.checkBoxStrogi.CheckedChanged += new System.EventHandler(this.checkBoxStrogi_CheckedChanged);
            // 
            // checkBoxPoluotvoren
            // 
            this.checkBoxPoluotvoren.AutoSize = true;
            this.checkBoxPoluotvoren.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBoxPoluotvoren.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBoxPoluotvoren.Location = new System.Drawing.Point(144, 3);
            this.checkBoxPoluotvoren.Name = "checkBoxPoluotvoren";
            this.checkBoxPoluotvoren.Size = new System.Drawing.Size(135, 44);
            this.checkBoxPoluotvoren.TabIndex = 1;
            this.checkBoxPoluotvoren.Text = "Poluotvoren režim";
            this.checkBoxPoluotvoren.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxPoluotvoren.UseVisualStyleBackColor = true;
            this.checkBoxPoluotvoren.CheckedChanged += new System.EventHandler(this.checkBoxPoluotvoren_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(305, 327);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(304, 27);
            this.comboBox1.TabIndex = 2;
            // 
            // groupBoxZatvorenici
            // 
            this.groupBoxZatvorenici.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxZatvorenici.Controls.Add(this.tableLayoutPanel10);
            this.groupBoxZatvorenici.Controls.Add(this.tableLayoutPanel9);
            this.groupBoxZatvorenici.Controls.Add(this.listViewZatvorenici);
            this.groupBoxZatvorenici.Location = new System.Drawing.Point(48, 367);
            this.groupBoxZatvorenici.Name = "groupBoxZatvorenici";
            this.groupBoxZatvorenici.Size = new System.Drawing.Size(717, 304);
            this.groupBoxZatvorenici.TabIndex = 3;
            this.groupBoxZatvorenici.TabStop = false;
            this.groupBoxZatvorenici.Text = "Zatvorenici";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.buttonIzmeniZatvorenika, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.buttonObrisiZatvorenika, 1, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(511, 25);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel10.TabIndex = 5;
            // 
            // buttonIzmeniZatvorenika
            // 
            this.buttonIzmeniZatvorenika.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniZatvorenika.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniZatvorenika.Name = "buttonIzmeniZatvorenika";
            this.buttonIzmeniZatvorenika.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniZatvorenika.TabIndex = 1;
            this.buttonIzmeniZatvorenika.Text = "Izmeni";
            this.buttonIzmeniZatvorenika.UseVisualStyleBackColor = true;
            this.buttonIzmeniZatvorenika.Click += new System.EventHandler(this.buttonIzmeniZatvorenika_Click);
            // 
            // buttonObrisiZatvorenika
            // 
            this.buttonObrisiZatvorenika.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiZatvorenika.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiZatvorenika.Name = "buttonObrisiZatvorenika";
            this.buttonObrisiZatvorenika.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiZatvorenika.TabIndex = 2;
            this.buttonObrisiZatvorenika.Text = "Obriši";
            this.buttonObrisiZatvorenika.UseVisualStyleBackColor = true;
            this.buttonObrisiZatvorenika.Click += new System.EventHandler(this.buttonObrisiZatvorenika_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.buttonDodajZatvorenika, 0, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(6, 25);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(100, 43);
            this.tableLayoutPanel9.TabIndex = 4;
            // 
            // buttonDodajZatvorenika
            // 
            this.buttonDodajZatvorenika.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajZatvorenika.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajZatvorenika.Name = "buttonDodajZatvorenika";
            this.buttonDodajZatvorenika.Size = new System.Drawing.Size(94, 37);
            this.buttonDodajZatvorenika.TabIndex = 0;
            this.buttonDodajZatvorenika.Text = "Dodaj";
            this.buttonDodajZatvorenika.UseVisualStyleBackColor = true;
            this.buttonDodajZatvorenika.Click += new System.EventHandler(this.buttonDodajZatvorenika_Click);
            // 
            // listViewZatvorenici
            // 
            this.listViewZatvorenici.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewZatvorenici.HideSelection = false;
            this.listViewZatvorenici.Location = new System.Drawing.Point(3, 74);
            this.listViewZatvorenici.Name = "listViewZatvorenici";
            this.listViewZatvorenici.Size = new System.Drawing.Size(711, 227);
            this.listViewZatvorenici.TabIndex = 3;
            this.listViewZatvorenici.UseCompatibleStateImageBehavior = false;
            this.listViewZatvorenici.SelectedIndexChanged += new System.EventHandler(this.listViewZatvorenici_SelectedIndexChanged);
            this.listViewZatvorenici.DoubleClick += new System.EventHandler(this.listViewZatvorenici_DoubleClick);
            // 
            // groupBoxZaposleni
            // 
            this.groupBoxZaposleni.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxZaposleni.Controls.Add(this.tableLayoutPanel13);
            this.groupBoxZaposleni.Controls.Add(this.tableLayoutPanel12);
            this.groupBoxZaposleni.Controls.Add(this.tableLayoutPanel11);
            this.groupBoxZaposleni.Controls.Add(this.listViewZaposleni);
            this.groupBoxZaposleni.Location = new System.Drawing.Point(48, 12);
            this.groupBoxZaposleni.Name = "groupBoxZaposleni";
            this.groupBoxZaposleni.Size = new System.Drawing.Size(717, 304);
            this.groupBoxZaposleni.TabIndex = 0;
            this.groupBoxZaposleni.TabStop = false;
            this.groupBoxZaposleni.Text = "Zaposleni";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel13.ColumnCount = 4;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.Controls.Add(this.radioButtonSvi, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.radioButtonAdministracija, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.radioButtonPsiholozi, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.radioButtonObezbedjenje, 3, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(171, 22);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(322, 46);
            this.tableLayoutPanel13.TabIndex = 10;
            // 
            // radioButtonSvi
            // 
            this.radioButtonSvi.AutoSize = true;
            this.radioButtonSvi.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonSvi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonSvi.Location = new System.Drawing.Point(3, 3);
            this.radioButtonSvi.Name = "radioButtonSvi";
            this.radioButtonSvi.Size = new System.Drawing.Size(74, 40);
            this.radioButtonSvi.TabIndex = 1;
            this.radioButtonSvi.TabStop = true;
            this.radioButtonSvi.Text = "Svi";
            this.radioButtonSvi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonSvi.UseVisualStyleBackColor = true;
            this.radioButtonSvi.CheckedChanged += new System.EventHandler(this.radioButtonSvi_CheckedChanged);
            // 
            // radioButtonAdministracija
            // 
            this.radioButtonAdministracija.AutoSize = true;
            this.radioButtonAdministracija.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonAdministracija.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonAdministracija.Location = new System.Drawing.Point(83, 3);
            this.radioButtonAdministracija.Name = "radioButtonAdministracija";
            this.radioButtonAdministracija.Size = new System.Drawing.Size(74, 40);
            this.radioButtonAdministracija.TabIndex = 2;
            this.radioButtonAdministracija.TabStop = true;
            this.radioButtonAdministracija.Text = "Administracija";
            this.radioButtonAdministracija.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonAdministracija.UseVisualStyleBackColor = true;
            this.radioButtonAdministracija.CheckedChanged += new System.EventHandler(this.radioButtonAdministracija_CheckedChanged);
            // 
            // radioButtonPsiholozi
            // 
            this.radioButtonPsiholozi.AutoSize = true;
            this.radioButtonPsiholozi.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonPsiholozi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonPsiholozi.Location = new System.Drawing.Point(163, 3);
            this.radioButtonPsiholozi.Name = "radioButtonPsiholozi";
            this.radioButtonPsiholozi.Size = new System.Drawing.Size(74, 40);
            this.radioButtonPsiholozi.TabIndex = 3;
            this.radioButtonPsiholozi.TabStop = true;
            this.radioButtonPsiholozi.Text = "Psiholozi";
            this.radioButtonPsiholozi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonPsiholozi.UseVisualStyleBackColor = true;
            this.radioButtonPsiholozi.CheckedChanged += new System.EventHandler(this.radioButtonPsiholozi_CheckedChanged);
            // 
            // radioButtonObezbedjenje
            // 
            this.radioButtonObezbedjenje.AutoSize = true;
            this.radioButtonObezbedjenje.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonObezbedjenje.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radioButtonObezbedjenje.Location = new System.Drawing.Point(243, 3);
            this.radioButtonObezbedjenje.Name = "radioButtonObezbedjenje";
            this.radioButtonObezbedjenje.Size = new System.Drawing.Size(76, 40);
            this.radioButtonObezbedjenje.TabIndex = 4;
            this.radioButtonObezbedjenje.TabStop = true;
            this.radioButtonObezbedjenje.Text = "Obezbeđenje";
            this.radioButtonObezbedjenje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonObezbedjenje.UseVisualStyleBackColor = true;
            this.radioButtonObezbedjenje.CheckedChanged += new System.EventHandler(this.radioButtonObezbedjenje_CheckedChanged);
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.buttonIzmeniZaposlenog, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.buttonObrisiZaposlenog, 1, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(514, 22);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(200, 43);
            this.tableLayoutPanel12.TabIndex = 9;
            // 
            // buttonIzmeniZaposlenog
            // 
            this.buttonIzmeniZaposlenog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonIzmeniZaposlenog.Location = new System.Drawing.Point(3, 3);
            this.buttonIzmeniZaposlenog.Name = "buttonIzmeniZaposlenog";
            this.buttonIzmeniZaposlenog.Size = new System.Drawing.Size(94, 37);
            this.buttonIzmeniZaposlenog.TabIndex = 5;
            this.buttonIzmeniZaposlenog.Text = "Izmeni";
            this.buttonIzmeniZaposlenog.UseVisualStyleBackColor = true;
            this.buttonIzmeniZaposlenog.Click += new System.EventHandler(this.buttonIzmeniZaposlenog_Click);
            // 
            // buttonObrisiZaposlenog
            // 
            this.buttonObrisiZaposlenog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonObrisiZaposlenog.Location = new System.Drawing.Point(103, 3);
            this.buttonObrisiZaposlenog.Name = "buttonObrisiZaposlenog";
            this.buttonObrisiZaposlenog.Size = new System.Drawing.Size(94, 37);
            this.buttonObrisiZaposlenog.TabIndex = 6;
            this.buttonObrisiZaposlenog.Text = "Obriši";
            this.buttonObrisiZaposlenog.UseVisualStyleBackColor = true;
            this.buttonObrisiZaposlenog.Click += new System.EventHandler(this.buttonObrisiZaposlenog_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.buttonDodajZaposlenog, 0, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(100, 43);
            this.tableLayoutPanel11.TabIndex = 8;
            // 
            // buttonDodajZaposlenog
            // 
            this.buttonDodajZaposlenog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonDodajZaposlenog.Location = new System.Drawing.Point(3, 3);
            this.buttonDodajZaposlenog.Name = "buttonDodajZaposlenog";
            this.buttonDodajZaposlenog.Size = new System.Drawing.Size(94, 37);
            this.buttonDodajZaposlenog.TabIndex = 0;
            this.buttonDodajZaposlenog.Text = "Dodaj";
            this.buttonDodajZaposlenog.UseVisualStyleBackColor = true;
            this.buttonDodajZaposlenog.Click += new System.EventHandler(this.buttonDodajZaposlenog_Click);
            // 
            // listViewZaposleni
            // 
            this.listViewZaposleni.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewZaposleni.HideSelection = false;
            this.listViewZaposleni.Location = new System.Drawing.Point(3, 74);
            this.listViewZaposleni.Name = "listViewZaposleni";
            this.listViewZaposleni.Size = new System.Drawing.Size(711, 227);
            this.listViewZaposleni.TabIndex = 7;
            this.listViewZaposleni.UseCompatibleStateImageBehavior = false;
            this.listViewZaposleni.SelectedIndexChanged += new System.EventHandler(this.listViewZaposleni_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Upravnik zatvorske jedinice:";
            // 
            // FormPregledZatvorskeJedinice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(854, 621);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxZaposleni);
            this.Controls.Add(this.groupBoxTerminiPosete);
            this.Controls.Add(this.groupBoxZatvorenici);
            this.Controls.Add(this.groupBoxTerminiSetnje);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.groupBoxRezim);
            this.Controls.Add(this.groupBoxCelijskiPeriod);
            this.Controls.Add(this.groupBoxFirme);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimizeBox = false;
            this.Name = "FormPregledZatvorskeJedinice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Pregled zatvorske jedinice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPregledZatvorskeJedinice_FormClosing);
            this.Load += new System.EventHandler(this.FormPregledZatvorskeJedinice_Load);
            this.groupBoxCelijskiPeriod.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.groupBoxFirme.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBoxTerminiPosete.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBoxTerminiSetnje.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBoxRezim.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.groupBoxZatvorenici.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.groupBoxZaposleni.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxCelijskiPeriod;
        private System.Windows.Forms.ListView listViewCelijskiPeriodi;
        private System.Windows.Forms.GroupBox groupBoxFirme;
        private System.Windows.Forms.ListView listViewFirme;
        private System.Windows.Forms.GroupBox groupBoxTerminiSetnje;
        private System.Windows.Forms.ListView listViewTerminiSetnje;
        private System.Windows.Forms.GroupBox groupBoxTerminiPosete;
        private System.Windows.Forms.ListView listViewTerminiPosete;
        private System.Windows.Forms.GroupBox groupBoxRezim;
        private System.Windows.Forms.CheckBox checkBoxStrogi;
        private System.Windows.Forms.CheckBox checkBoxPoluotvoren;
        private System.Windows.Forms.CheckBox checkBoxOtvoren;
        private System.Windows.Forms.Button buttonIzmeniCP;
        private System.Windows.Forms.Button buttonObrisiCP;
        private System.Windows.Forms.Button buttonDodajCP;
        private System.Windows.Forms.Button buttonIzmeniTS;
        private System.Windows.Forms.Button buttonDodajTS;
        private System.Windows.Forms.Button buttonObrisiTS;
        private System.Windows.Forms.Button buttonObrisiFirmu;
        private System.Windows.Forms.Button buttonIzmeniFirmu;
        private System.Windows.Forms.Button buttonDodajFirmu;
        private System.Windows.Forms.Button buttonObrisiTP;
        private System.Windows.Forms.Button buttonIzmeniTP;
        private System.Windows.Forms.Button buttonDodajTP;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBoxZatvorenici;
        private System.Windows.Forms.Button buttonObrisiZatvorenika;
        private System.Windows.Forms.Button buttonIzmeniZatvorenika;
        private System.Windows.Forms.Button buttonDodajZatvorenika;
        private System.Windows.Forms.ListView listViewZatvorenici;
        private System.Windows.Forms.GroupBox groupBoxZaposleni;
        private System.Windows.Forms.RadioButton radioButtonObezbedjenje;
        private System.Windows.Forms.RadioButton radioButtonPsiholozi;
        private System.Windows.Forms.RadioButton radioButtonAdministracija;
        private System.Windows.Forms.RadioButton radioButtonSvi;
        private System.Windows.Forms.Button buttonObrisiZaposlenog;
        private System.Windows.Forms.Button buttonIzmeniZaposlenog;
        private System.Windows.Forms.Button buttonDodajZaposlenog;
        private System.Windows.Forms.ListView listViewZaposleni;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
    }
}